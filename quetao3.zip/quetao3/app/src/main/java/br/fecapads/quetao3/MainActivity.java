package br.fecapads.quetao3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Referência ao TextView com o ID corrigido
        TextView welcomeText = findViewById(R.id.textViewWelcome);
        welcomeText.setText("Bem-vindo ao Tem de Tudo!"); // Exibe a mensagem de boas-vindas

        Button btnIniciarCadastro = findViewById(R.id.btnIniciarCadastro);
        btnIniciarCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Quando o botão for clicado, inicia o cadastro
                Intent intent = new Intent(MainActivity.this, CadastroActivity.class);
                startActivity(intent);
            }
        });
    }
}
